﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConverterApp.Converters.Base
{
    public enum FileType
    {
        Image,
        Document
    }
}
