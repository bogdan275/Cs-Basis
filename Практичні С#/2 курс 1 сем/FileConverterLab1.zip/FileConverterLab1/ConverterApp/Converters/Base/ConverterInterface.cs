﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConverterApp.Converters.Base
{
    public interface ConverterInterface
    {
        string TargetExtension { get; }
        bool CanConvert(FileInfo fileInfo);
        void Convert(FileInfo fileInfo, string outputPath);
    }
}
