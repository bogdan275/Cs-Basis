﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using ConverterApp.Converters.Base;
using SixLabors.ImageSharp; 
using SixLabors.ImageSharp.Formats; 
using SixLabors.ImageSharp.Formats.Bmp;
using SixLabors.ImageSharp.Formats.Gif;
using SixLabors.ImageSharp.Formats.Jpeg;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.Processing;

namespace ConverterApp.Converters
{
    public class ImgConverter : ConverterInterface
    {
        private readonly string _targetExtension;
        private static readonly string[] SupportedFormats = { ".jpg", ".png", ".bmp", ".gif" };

        public string TargetExtension
        {
            get { return _targetExtension; }
        }

        public ImgConverter(string targetExtension)
        {
            if (!SupportedFormats.Contains(targetExtension.ToLower()))
                throw new ArgumentException($"Unsupported format: {targetExtension}");

            _targetExtension = targetExtension.ToLower();
        }

        public bool CanConvert(FileInfo fileInfo)
        {
            string ext = fileInfo.Extension.ToLower();
            return SupportedFormats.Contains(ext) && ext != _targetExtension;
        }

        public void Convert(FileInfo sourceFile, string targetPath)
        {
            using (var image = SixLabors.ImageSharp.Image.Load(sourceFile.FullName))
            {
                var ext = _targetExtension.StartsWith(".") ? _targetExtension.Substring(1) : _targetExtension;
                ext = ext.ToLowerInvariant();

                switch (ext)
                {
                    case "jpg":
                        image.Save(targetPath, new JpegEncoder());
                        break;
                    case "png":
                        image.Save(targetPath, new PngEncoder());
                        break;
                    case "gif":
                        image.Save(targetPath, new GifEncoder());
                        break;
                    case "bmp":
                        image.Save(targetPath, new BmpEncoder());
                        break;
                    default:
                        break;
                }
            }
        }

        public static string[] GetSupportedFormats()
        {
            return SupportedFormats;
        }
    }
}
