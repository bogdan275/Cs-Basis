﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;
using ConverterApp.Converters.Base;
using Spire.Doc;

namespace ConverterApp.Converters
{
    public class DocConverter : ConverterInterface
    {
        private readonly string _targetExtension;
        private static readonly string[] SupportedFormats = { ".docx", ".pdf" };

        public string TargetExtension
        {
            get { return _targetExtension; }
        }
        public DocConverter(string targetExtension)
        {
            if (!SupportedFormats.Contains(targetExtension.ToLower()))
                throw new ArgumentException($"Unsupported format: {targetExtension}");

            _targetExtension = targetExtension.ToLower();
        }

        public bool CanConvert(FileInfo fileInfo)
        {
            string ext = fileInfo.Extension.ToLower();
            return SupportedFormats.Contains(ext) && ext != _targetExtension;
        }

        public void Convert(FileInfo sourceFile, string targetPath)
        {
            using (var document = new Spire.Doc.Document())
            {
                FileFormat sourceFormat = sourceFile.Extension.ToLower() == ".pdf"
                    ? FileFormat.PDF
                    : FileFormat.Docx;

                document.LoadFromFile(sourceFile.FullName, sourceFormat);

                FileFormat targetFormat = _targetExtension == ".pdf"
                    ? FileFormat.PDF
                    : FileFormat.Docx;

                document.SaveToFile(targetPath, targetFormat);
            }
        }

        public static string[] GetSupportedFormats()
        {
            return SupportedFormats;
        }
    }
}
