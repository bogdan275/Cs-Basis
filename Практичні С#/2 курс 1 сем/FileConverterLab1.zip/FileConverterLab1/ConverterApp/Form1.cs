﻿using System.Text;
using ConverterApp.Converters;
using ConverterApp.Converters.Base;
using ConverterApp.Core;

namespace ConverterApp
{
    public partial class Form1 : Form
    {
        private FileManager _filemanager = new FileManager();
        private ConverterManager _converterManager = new ConverterManager();

        private readonly string _defaultOutputPath = "C:\\Users\\Home\\source\\repos\\FileConverterFinal\\ConverterApp\\Output\\";
        private string _outputPath;

        public Form1()
        {
            InitializeComponent();
            _outputPath = _defaultOutputPath;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBoxImageFormats.Enabled = false;
            comboBoxDocumentFormat.Enabled = false;

            labelOutputPath.Text = $"{_outputPath}";

            try
            {
                Directory.CreateDirectory(_outputPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не вдалося створити стандартну папку: {ex.Message}",
                    "Попередження",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
            }

            UpdateConvertButton();
        }

        private void buttonSelectFiles_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Multiselect = true,
                Title = "Виберіть файли",
                Filter = "Підтримувані формати|*.docx;*.pdf;*.jpg;*.jpeg;*.png|Всі файли (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                foreach (var filePath in openFileDialog.FileNames)
                {
                    FileInfo fi = new FileInfo(filePath);
                    listBoxSelectedFiles.Items.Add(fi.Name);
                    _filemanager.AddFile(fi);
                }

                FillComboBoxes();
                UpdateConvertButton();
            }
        }

        private void buttonSelectOutputFolder_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Оберіть папку для збереження конвертованих файлів";
                folderDialog.ShowNewFolderButton = true;
                folderDialog.SelectedPath = _outputPath;

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    _outputPath = folderDialog.SelectedPath;
                    labelOutputPath.Text = $"Папка виводу: {_outputPath}";
                }
            }
        }

        private void FillComboBoxes()
        {
            comboBoxDocumentFormat.Items.Clear();
            comboBoxImageFormats.Items.Clear();
            comboBoxDocumentFormat.ResetText();
            comboBoxImageFormats.ResetText();
            comboBoxDocumentFormat.Enabled = false;
            comboBoxImageFormats.Enabled = false;

            var files = _filemanager.GetFiles();
            if (!files.Any()) return;

            var extensions = files.Select(f => f.Extension.ToLower()).Distinct().ToList();

            var documentExtensions = DocConverter.GetSupportedFormats()
                .Where(ext => extensions.Contains(ext))
                .ToList();

            if (documentExtensions.Any())
            {
                comboBoxDocumentFormat.Enabled = true;

                foreach (var format in DocConverter.GetSupportedFormats())
                {
                    if (!documentExtensions.Contains(format) ||
                        documentExtensions.Count > 1 ||
                        extensions.Count > documentExtensions.Count)
                    {
                        comboBoxDocumentFormat.Items.Add(format);
                    }
                }

                if (comboBoxDocumentFormat.Items.Count > 0)
                {
                    comboBoxDocumentFormat.SelectedIndex = 0;
                }
            }

            var imageExtensions = ImgConverter.GetSupportedFormats()
                .Where(ext => extensions.Contains(ext))
                .ToList();

            if (imageExtensions.Any())
            {
                comboBoxImageFormats.Enabled = true;

                var allImageFormats = ImgConverter.GetSupportedFormats();

                foreach (var format in allImageFormats)
                {
                    bool hasJpgOrJpeg = imageExtensions.Contains(".jpg") || imageExtensions.Contains(".jpeg");

                    if ((format == ".jpg" || format == ".jpeg") && hasJpgOrJpeg &&
                        imageExtensions.Count == 1 &&
                        extensions.Count == imageExtensions.Count)
                    {
                        continue;
                    }

                    if (!imageExtensions.Contains(format) ||
                        imageExtensions.Count > 1 ||
                        extensions.Count > imageExtensions.Count)
                    {
                        comboBoxImageFormats.Items.Add(format);
                    }
                }

                if (comboBoxImageFormats.Items.Count > 0)
                {
                    comboBoxImageFormats.SelectedIndex = 0;
                }
            }
        }

        private void UpdateConvertButton()
        {
            buttonConvert.Enabled = _filemanager.GetFiles().Any();
        }

        private void buttonConvert_Click(object sender, EventArgs e)
        {
            var filesToConvert = _filemanager.GetFiles();
            if (!filesToConvert.Any())
            {
                MessageBox.Show("Будь ласка, спершу виберіть файли для конвертації.",
                    "Немає файлів",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            string targetImageExt = comboBoxImageFormats.SelectedItem?.ToString();
            string targetDocExt = comboBoxDocumentFormat.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(targetImageExt) && string.IsNullOrEmpty(targetDocExt))
            {
                MessageBox.Show("Будь ласка, виберіть цільовий формат.",
                    "Не вибрано формат",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Directory.CreateDirectory(_outputPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Не вдалося створити вихідну теку: {_outputPath}\nПомилка: {ex.Message}",
                    "Помилка директорії",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                return;
            }

            int successfulConversions = 0;
            StringBuilder errors = new StringBuilder();

            foreach (var file in filesToConvert)
            {
                string targetExtension = null;
                var fileType = ConverterManager.GetFileType(file.Extension);

                if (fileType == FileType.Image)
                {
                    targetExtension = targetImageExt;
                }
                else if (fileType == FileType.Document)
                {
                    targetExtension = targetDocExt;
                }

                if (string.IsNullOrEmpty(targetExtension))
                {
                    continue;
                }

                if (file.Extension.Equals(targetExtension, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                var converter = _converterManager.GetConverter(file, targetExtension);

                if (converter != null)
                {
                    try
                    {
                        string outputFileName = Path.ChangeExtension(file.Name, converter.TargetExtension);
                        string fullOutputPath = Path.Combine(_outputPath, outputFileName);

                        converter.Convert(file, fullOutputPath);
                        successfulConversions++;
                    }
                    catch (Exception ex)
                    {
                        errors.AppendLine($"Не вдалося конвертувати {file.Name}: {ex.Message}");
                    }
                }
                else
                {
                    errors.AppendLine($"Конвертер для {file.Name} → {targetExtension} не знайдено");
                }
            }

            StringBuilder summary = new StringBuilder();
            summary.AppendLine($"Конвертацію завершено!");
            summary.AppendLine($"Успішно конвертовано: {successfulConversions} файл(ів).");

            if (errors.Length > 0)
            {
                summary.AppendLine("\nВиникли помилки:");
                summary.Append(errors.ToString());
                MessageBox.Show(summary.ToString(), "Завершено з помилками", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                MessageBox.Show(summary.ToString(), "Успішно", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void buttonClearList_Click(object sender, EventArgs e)
        {
            _filemanager.ClearFileList();
            listBoxSelectedFiles.Items.Clear();
            FillComboBoxes();

            comboBoxDocumentFormat.Enabled = false;
            comboBoxImageFormats.Enabled = false;

            _outputPath = _defaultOutputPath;
            labelOutputPath.Text = $"{_outputPath}";

            UpdateConvertButton();
        }
    }
}
