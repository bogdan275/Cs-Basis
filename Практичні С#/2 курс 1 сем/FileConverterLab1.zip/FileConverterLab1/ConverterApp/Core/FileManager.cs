﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConverterApp.Core
{
    public class FileManager
    {
        private List<FileInfo> _files = new List<FileInfo>();

        public void AddFile(FileInfo file)
        {
            if (!_files.Any(f => f.FullName == file.FullName))
            {
                _files.Add(file);
            }
        }

        public List<FileInfo> GetFiles()
        {
            return _files;
        }

        public void ClearFileList()
        {
            _files.Clear();
        }
    }
}
