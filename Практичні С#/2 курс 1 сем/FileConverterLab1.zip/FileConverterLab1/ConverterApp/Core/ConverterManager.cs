﻿using System;
using System.Collections.Generic;
using System.Text;
using ConverterApp.Converters;
using ConverterApp.Converters.Base;

namespace ConverterApp.Core
{
    public class ConverterManager
    {
        private List<ConverterInterface> _converters = new List<ConverterInterface>();

        public ConverterManager()
        {
            _converters.Add(new ImgConverter(".png"));
            _converters.Add(new ImgConverter(".jpg"));
            _converters.Add(new ImgConverter(".bmp"));
            _converters.Add(new ImgConverter(".gif"));

            _converters.Add(new DocConverter(".pdf"));
            _converters.Add(new DocConverter(".docx"));
        }

        public ConverterInterface GetConverter(FileInfo file, string targetExtension)
        {
            return _converters.FirstOrDefault(c =>
                c.TargetExtension.Equals(targetExtension.ToLower()) &&
                c.CanConvert(file)
            );
        }

        public static FileType? GetFileType(string extension)
        {
            string ext = extension.ToLower();

            if (ImgConverter.GetSupportedFormats().Contains(ext))
            {
                return FileType.Image;
            }


            if (DocConverter.GetSupportedFormats().Contains(ext))
            {
                return FileType.Document;
            }

            return null;
        }
    }
}
