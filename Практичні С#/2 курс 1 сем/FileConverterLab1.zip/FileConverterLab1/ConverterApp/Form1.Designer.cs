﻿namespace ConverterApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonConvert = new Button();
            buttonClearList = new Button();
            buttonSelectFiles = new Button();
            comboBoxDocumentFormat = new ComboBox();
            comboBoxImageFormats = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            listBoxSelectedFiles = new ListBox();
            buttonSelectOutputFolder = new Button();
            labelOutputPath = new Label();
            SuspendLayout();
            // 
            // buttonConvert
            // 
            buttonConvert.Location = new Point(479, 151);
            buttonConvert.Name = "buttonConvert";
            buttonConvert.Size = new Size(129, 39);
            buttonConvert.TabIndex = 15;
            buttonConvert.Text = "Convert";
            buttonConvert.UseVisualStyleBackColor = true;
            buttonConvert.Click += buttonConvert_Click;
            // 
            // buttonClearList
            // 
            buttonClearList.Location = new Point(344, 151);
            buttonClearList.Name = "buttonClearList";
            buttonClearList.Size = new Size(129, 39);
            buttonClearList.TabIndex = 14;
            buttonClearList.Text = "Clear";
            buttonClearList.UseVisualStyleBackColor = true;
            buttonClearList.Click += buttonClearList_Click;
            // 
            // buttonSelectFiles
            // 
            buttonSelectFiles.Location = new Point(344, 399);
            buttonSelectFiles.Name = "buttonSelectFiles";
            buttonSelectFiles.Size = new Size(129, 39);
            buttonSelectFiles.TabIndex = 13;
            buttonSelectFiles.Text = "Select Files";
            buttonSelectFiles.UseVisualStyleBackColor = true;
            buttonSelectFiles.Click += buttonSelectFiles_Click;
            // 
            // comboBoxDocumentFormat
            // 
            comboBoxDocumentFormat.Enabled = false;
            comboBoxDocumentFormat.FormattingEnabled = true;
            comboBoxDocumentFormat.Location = new Point(344, 117);
            comboBoxDocumentFormat.Name = "comboBoxDocumentFormat";
            comboBoxDocumentFormat.Size = new Size(264, 28);
            comboBoxDocumentFormat.TabIndex = 12;
            // 
            // comboBoxImageFormats
            // 
            comboBoxImageFormats.Enabled = false;
            comboBoxImageFormats.FormattingEnabled = true;
            comboBoxImageFormats.Location = new Point(344, 63);
            comboBoxImageFormats.Name = "comboBoxImageFormats";
            comboBoxImageFormats.Size = new Size(264, 28);
            comboBoxImageFormats.TabIndex = 11;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(344, 94);
            label2.Name = "label2";
            label2.Size = new Size(127, 20);
            label2.TabIndex = 10;
            label2.Text = "Document format";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(344, 40);
            label1.Name = "label1";
            label1.Size = new Size(106, 20);
            label1.TabIndex = 9;
            label1.Text = "Image formats";
            // 
            // listBoxSelectedFiles
            // 
            listBoxSelectedFiles.FormattingEnabled = true;
            listBoxSelectedFiles.Location = new Point(0, 40);
            listBoxSelectedFiles.Name = "listBoxSelectedFiles";
            listBoxSelectedFiles.Size = new Size(328, 404);
            listBoxSelectedFiles.TabIndex = 8;
            // 
            // buttonSelectOutputFolder
            // 
            buttonSelectOutputFolder.Location = new Point(479, 399);
            buttonSelectOutputFolder.Name = "buttonSelectOutputFolder";
            buttonSelectOutputFolder.Size = new Size(129, 39);
            buttonSelectOutputFolder.TabIndex = 16;
            buttonSelectOutputFolder.Text = "Select Folder";
            buttonSelectOutputFolder.UseVisualStyleBackColor = true;
            buttonSelectOutputFolder.Click += buttonSelectOutputFolder_Click;
            // 
            // labelOutputPath
            // 
            labelOutputPath.AutoSize = true;
            labelOutputPath.Location = new Point(12, 9);
            labelOutputPath.Name = "labelOutputPath";
            labelOutputPath.Size = new Size(50, 20);
            labelOutputPath.TabIndex = 17;
            labelOutputPath.Text = "label3";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(631, 450);
            Controls.Add(labelOutputPath);
            Controls.Add(buttonSelectOutputFolder);
            Controls.Add(buttonConvert);
            Controls.Add(buttonClearList);
            Controls.Add(buttonSelectFiles);
            Controls.Add(comboBoxDocumentFormat);
            Controls.Add(comboBoxImageFormats);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(listBoxSelectedFiles);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonConvert;
        private Button buttonClearList;
        private Button buttonSelectFiles;
        private ComboBox comboBoxDocumentFormat;
        private ComboBox comboBoxImageFormats;
        private Label label2;
        private Label label1;
        private ListBox listBoxSelectedFiles;
        private Button buttonSelectOutputFolder;
        private Label labelOutputPath;
    }
}
