﻿namespace Lab_2_Database
{
    public class Class1
    {

    }
}
