﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Database_Models.Migrations
{
    /// <inheritdoc />
    public partial class init : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "active_ingredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_active_ingredients", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "brands",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_brands", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "refrigerators",
                columns: table => new
                {
                    Refrigerator_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Refrigerator_Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_refrigerators", x => x.Refrigerator_Id);
                });

            migrationBuilder.CreateTable(
                name: "return_policies",
                columns: table => new
                {
                    Return_Policy_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Can_Return = table.Column<bool>(type: "bit", nullable: false),
                    Reason = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Signature1 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Signature2 = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Pasport_Data = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SaleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_return_policies", x => x.Return_Policy_Id);
                });

            migrationBuilder.CreateTable(
                name: "shelves",
                columns: table => new
                {
                    ShelfId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Zone = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ShelfNumber = table.Column<int>(type: "int", nullable: false),
                    RowNumber = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shelves", x => x.ShelfId);
                });

            migrationBuilder.CreateTable(
                name: "suppliers",
                columns: table => new
                {
                    SupplierId = table.Column<int>(type: "int", maxLength: 50, nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SupplierName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_suppliers", x => x.SupplierId);
                });

            migrationBuilder.CreateTable(
                name: "medicines",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Storage_Conditions = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Is_Child_form = table.Column<bool>(type: "bit", nullable: false),
                    Seasonal_Status = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Dosage = table.Column<int>(type: "int", nullable: false),
                    Release_Form = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Prescription_Required = table.Column<bool>(type: "bit", nullable: false),
                    BrandId = table.Column<int>(type: "int", nullable: false),
                    Active_IngredientId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_medicines", x => x.Id);
                    table.ForeignKey(
                        name: "FK_medicines_active_ingredients_Active_IngredientId",
                        column: x => x.Active_IngredientId,
                        principalTable: "active_ingredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_medicines_brands_BrandId",
                        column: x => x.BrandId,
                        principalTable: "brands",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "refrigerator_logs",
                columns: table => new
                {
                    Log_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Min_Temp = table.Column<double>(type: "float", nullable: false),
                    Max_Temp = table.Column<double>(type: "float", nullable: false),
                    Current_Temp = table.Column<double>(type: "float", nullable: false),
                    Log_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    RefrigeratorId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_refrigerator_logs", x => x.Log_Id);
                    table.ForeignKey(
                        name: "FK_refrigerator_logs_refrigerators_RefrigeratorId",
                        column: x => x.RefrigeratorId,
                        principalTable: "refrigerators",
                        principalColumn: "Refrigerator_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "purchase_orders",
                columns: table => new
                {
                    Purchase_Order_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Order_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Status = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SupplierId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_purchase_orders", x => x.Purchase_Order_Id);
                    table.ForeignKey(
                        name: "FK_purchase_orders_suppliers_SupplierId",
                        column: x => x.SupplierId,
                        principalTable: "suppliers",
                        principalColumn: "SupplierId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "recipes",
                columns: table => new
                {
                    Recipe_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Doctor_Name = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    Doctor_Phone = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Can_use_alternative = table.Column<bool>(type: "bit", nullable: false),
                    MedicineId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_recipes", x => x.Recipe_Id);
                    table.ForeignKey(
                        name: "FK_recipes_medicines_MedicineId",
                        column: x => x.MedicineId,
                        principalTable: "medicines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "shelf_items",
                columns: table => new
                {
                    Shelf_Item_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Face_Required = table.Column<int>(type: "int", nullable: false),
                    Face_Current = table.Column<int>(type: "int", nullable: false),
                    Location_Hint = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Last_Updated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    ShelfId = table.Column<int>(type: "int", nullable: false),
                    MedicineId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_shelf_items", x => x.Shelf_Item_Id);
                    table.ForeignKey(
                        name: "FK_shelf_items_medicines_MedicineId",
                        column: x => x.MedicineId,
                        principalTable: "medicines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_shelf_items_shelves_ShelfId",
                        column: x => x.ShelfId,
                        principalTable: "shelves",
                        principalColumn: "ShelfId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "batches",
                columns: table => new
                {
                    Batch_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Batch_Num = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Arrival_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Expiri_Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Stock_Quantity = table.Column<int>(type: "int", nullable: false),
                    MedicineId = table.Column<int>(type: "int", nullable: false),
                    Purchase_OrderId = table.Column<int>(type: "int", nullable: false),
                    RefrigeratorId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_batches", x => x.Batch_Id);
                    table.ForeignKey(
                        name: "FK_batches_medicines_MedicineId",
                        column: x => x.MedicineId,
                        principalTable: "medicines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_batches_purchase_orders_Purchase_OrderId",
                        column: x => x.Purchase_OrderId,
                        principalTable: "purchase_orders",
                        principalColumn: "Purchase_Order_Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_batches_refrigerators_RefrigeratorId",
                        column: x => x.RefrigeratorId,
                        principalTable: "refrigerators",
                        principalColumn: "Refrigerator_Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateTable(
                name: "purchase_order_items",
                columns: table => new
                {
                    Purchase_Order_Item_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Purchase_orderId = table.Column<int>(type: "int", nullable: false),
                    MedicineId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_purchase_order_items", x => x.Purchase_Order_Item_Id);
                    table.ForeignKey(
                        name: "FK_purchase_order_items_medicines_MedicineId",
                        column: x => x.MedicineId,
                        principalTable: "medicines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_purchase_order_items_purchase_orders_Purchase_orderId",
                        column: x => x.Purchase_orderId,
                        principalTable: "purchase_orders",
                        principalColumn: "Purchase_Order_Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "sales",
                columns: table => new
                {
                    Sale_Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Date_Of_Sale = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Customer_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Price = table.Column<decimal>(type: "decimal(10,2)", nullable: false),
                    MedicineId = table.Column<int>(type: "int", nullable: false),
                    BatchId = table.Column<int>(type: "int", nullable: false),
                    Return_Policy_Id = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_sales", x => x.Sale_Id);
                    table.ForeignKey(
                        name: "FK_sales_batches_BatchId",
                        column: x => x.BatchId,
                        principalTable: "batches",
                        principalColumn: "Batch_Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_sales_medicines_MedicineId",
                        column: x => x.MedicineId,
                        principalTable: "medicines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_sales_return_policies_Return_Policy_Id",
                        column: x => x.Return_Policy_Id,
                        principalTable: "return_policies",
                        principalColumn: "Return_Policy_Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.CreateIndex(
                name: "IX_batches_Batch_Num",
                table: "batches",
                column: "Batch_Num");

            migrationBuilder.CreateIndex(
                name: "IX_batches_MedicineId",
                table: "batches",
                column: "MedicineId");

            migrationBuilder.CreateIndex(
                name: "IX_batches_Purchase_OrderId",
                table: "batches",
                column: "Purchase_OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_batches_RefrigeratorId",
                table: "batches",
                column: "RefrigeratorId");

            migrationBuilder.CreateIndex(
                name: "IX_medicines_Active_IngredientId",
                table: "medicines",
                column: "Active_IngredientId");

            migrationBuilder.CreateIndex(
                name: "IX_medicines_BrandId",
                table: "medicines",
                column: "BrandId");

            migrationBuilder.CreateIndex(
                name: "IX_medicines_Name",
                table: "medicines",
                column: "Name");

            migrationBuilder.CreateIndex(
                name: "IX_purchase_order_items_MedicineId",
                table: "purchase_order_items",
                column: "MedicineId");

            migrationBuilder.CreateIndex(
                name: "IX_purchase_order_items_Purchase_orderId",
                table: "purchase_order_items",
                column: "Purchase_orderId");

            migrationBuilder.CreateIndex(
                name: "IX_purchase_orders_SupplierId",
                table: "purchase_orders",
                column: "SupplierId");

            migrationBuilder.CreateIndex(
                name: "IX_recipes_MedicineId",
                table: "recipes",
                column: "MedicineId");

            migrationBuilder.CreateIndex(
                name: "IX_refrigerator_logs_RefrigeratorId",
                table: "refrigerator_logs",
                column: "RefrigeratorId");

            migrationBuilder.CreateIndex(
                name: "IX_sales_BatchId",
                table: "sales",
                column: "BatchId");

            migrationBuilder.CreateIndex(
                name: "IX_sales_Date_Of_Sale",
                table: "sales",
                column: "Date_Of_Sale");

            migrationBuilder.CreateIndex(
                name: "IX_sales_MedicineId",
                table: "sales",
                column: "MedicineId");

            migrationBuilder.CreateIndex(
                name: "IX_sales_Return_Policy_Id",
                table: "sales",
                column: "Return_Policy_Id",
                unique: true,
                filter: "[Return_Policy_Id] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_shelf_items_MedicineId",
                table: "shelf_items",
                column: "MedicineId");

            migrationBuilder.CreateIndex(
                name: "IX_shelf_items_ShelfId",
                table: "shelf_items",
                column: "ShelfId");

            migrationBuilder.CreateIndex(
                name: "IX_suppliers_SupplierName",
                table: "suppliers",
                column: "SupplierName");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "purchase_order_items");

            migrationBuilder.DropTable(
                name: "recipes");

            migrationBuilder.DropTable(
                name: "refrigerator_logs");

            migrationBuilder.DropTable(
                name: "sales");

            migrationBuilder.DropTable(
                name: "shelf_items");

            migrationBuilder.DropTable(
                name: "batches");

            migrationBuilder.DropTable(
                name: "return_policies");

            migrationBuilder.DropTable(
                name: "shelves");

            migrationBuilder.DropTable(
                name: "medicines");

            migrationBuilder.DropTable(
                name: "purchase_orders");

            migrationBuilder.DropTable(
                name: "refrigerators");

            migrationBuilder.DropTable(
                name: "active_ingredients");

            migrationBuilder.DropTable(
                name: "brands");

            migrationBuilder.DropTable(
                name: "suppliers");
        }
    }
}
