﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Database_Models.Models
{
    public class Batch
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Batch_Id { get; set; }
        [Required]
        public string Batch_Num { get; set; }
        [Required]
        public DateTime Arrival_Date { get; set; }
        [Required]
        public DateTime Expiri_Date { get; set; }
        [Required]
        public int Stock_Quantity { get; set; }

        public int MedicineId { get; set; }
        public virtual Medicine Medicine { get; set; }

        public int Purchase_OrderId { get; set; }
        public virtual Purchase_Order Purchase_Order { get; set; }

        public int? RefrigeratorId { get; set; }
        public virtual Refrigerator Refrigerator { get; set; }

        public virtual ICollection<Sale> Sales { get; set; } = new HashSet<Sale>();

    }
}
