﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Task3;
class Program
{
    static void Main()
    {
        Song track1 = new Song("Звук 1", 3);
        Song track2 = new Song("Звук 2", 3);
        Song track3 = new Song("Звук 3", 4);


        Playlist playlist1 = new Playlist(new List<Song> { track1, track2 });
        Playlist playlist2 = new Playlist(new List<Song> { track3 });


        Console.WriteLine("Плейлист 1:");
        Console.WriteLine(playlist1);
        Console.WriteLine("Плейлист 2:");
        Console.WriteLine(playlist2);


        Playlist combinedPlaylist = playlist1 + playlist2;


        Console.WriteLine("З'єднані плейлисти:");
        Console.WriteLine(combinedPlaylist);


        Playlist removedTrackPlaylist = combinedPlaylist - track2;
        Console.WriteLine(removedTrackPlaylist);


        Console.WriteLine($"Плейлист 1 > Плейлист 2? {playlist1 > playlist2}");
        Console.WriteLine($"Плейлист 1 < Плейлист 2? {playlist1 < playlist2}");
        Console.WriteLine($"Плейлист 1 = Плейлист 2? {playlist1 == playlist2}");
        Console.WriteLine($"Плейлист 1 != Плейлист 2? {playlist1 != playlist2}");

        Playlist duplicatedPlaylist = playlist1 * 3;
        Console.WriteLine("Повтори плейлистів:");
        Console.WriteLine(duplicatedPlaylist);


        Playlist shuffledPlaylist = ~playlist1;
        Console.WriteLine("Перевернутий плейлист:");
        Console.WriteLine(shuffledPlaylist);


        string json = playlist1.ToJson();
        Console.WriteLine("Формат JSON:");
        Console.WriteLine(json);
        string xml = playlist1.ToXml();
        Console.WriteLine("Формат XML:");
        Console.WriteLine(xml);
    }
}





