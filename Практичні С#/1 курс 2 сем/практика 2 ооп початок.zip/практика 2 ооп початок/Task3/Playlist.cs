﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Text.Json;

namespace Task3
{
    public class Playlist
    {
        private List<Song> tracks;
        public int TrackCount => tracks.Count;
        public int TotalDuration => tracks.Sum(t => t.Duration);



        public Playlist(List<Song> initialTracks)
        {
            tracks = initialTracks ?? new List<Song>();
        }

        public Playlist()
        {
            tracks = new List<Song>();
        }


        public void AddTrack(Song track)
        {
            if (track != null)
            {
                tracks.Add(track);
            }
        }

        public void RemoveTrack(Song track)
        {
            if (track != null)
            {
                tracks.Remove(track);
                Console.WriteLine($"Пісня: {track} була видалена ");
            }
        }


        public static Playlist operator +(Playlist p1, Playlist p2)
        {
            var newPlaylist = new Playlist(p1.tracks.Concat(p2.tracks).ToList());
            return newPlaylist;
        }
        public static Playlist operator -(Playlist p, Song track)
        {
            var newPlaylist = new Playlist(p.tracks.ToList());
            newPlaylist.RemoveTrack(track);
            return newPlaylist;
        }
        public static bool operator >(Playlist p1, Playlist p2)
        {
            return p1.TotalDuration > p2.TotalDuration;
        }

        public static bool operator <(Playlist p1, Playlist p2)
        {
            return p1.TotalDuration < p2.TotalDuration;
        }
        public static bool operator ==(Playlist p1, Playlist p2)
        {
            return p1.TotalDuration == p2.TotalDuration;
        }
        public static bool operator !=(Playlist p1, Playlist p2)
        {
            return p1.TotalDuration != p2.TotalDuration;
        }
        public static Playlist operator *(Playlist p, int times)
        {
            var newPlaylist = new Playlist();
            for (int i = 0; i < times; i++)
            {
                newPlaylist.tracks.AddRange(p.tracks);
            }
            return newPlaylist;
        }
        public static Playlist operator ~(Playlist p)
        {
            var shuffledTracks = p.tracks.OrderBy(x => Guid.NewGuid()).ToList();
            return new Playlist(shuffledTracks);
        }



        public override string ToString()
        {
            return $"Плейлист складається з: {TrackCount} піень, загальна тривалість плейлиста : {TotalDuration} хвилин\n" +
                   string.Join("\n", tracks.Select(t => t.ToString()));
        }

        public string ToJson()
        {
            return System.Text.Json.JsonSerializer.Serialize(this);
        }

        public string ToXml()
        {
            var xmlSerializer = new XmlSerializer(typeof(Playlist));
            using (var stringWriter  = new StringWriter())
            {
                xmlSerializer.Serialize(stringWriter, this);
                return stringWriter.ToString();
            }
        }

        public override bool Equals(object obj)
        {
            if (obj is Playlist other)
            {
                return this.TotalDuration == other.TotalDuration && this.TrackCount == other.TrackCount;
            }
            return false;
        }
    }
}
