﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task3
{
    public class Song
    {
        public string Title { get; set; }
        public int Duration { get; set; }
        public Song(string title, int duration)
        {
            Title = title;
            Duration = duration;
        }
        public override string ToString()
        {
            return $"Назва: {Title}, тривалість: {Duration}";
        }
    }
}
