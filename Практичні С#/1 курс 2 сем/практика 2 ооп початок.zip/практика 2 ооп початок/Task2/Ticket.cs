﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Ticket
    {
        public string TicketNumber { get; set; }
        public Passenger Passenger { get; set; }
        public Vehicle Vehicle { get; set; }
        public Ticket(string ticketNumber, Passenger passenger, Vehicle vehicle)
        {
            TicketNumber = ticketNumber;
            Passenger = passenger;
            Vehicle = vehicle;
        }
    }
}
