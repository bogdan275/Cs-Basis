﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Bus : Vehicle
    {
        public int Capacity { get; set; }
        public Bus(string licensePlate, string model, int capacity) : base(licensePlate, model)
        {
            Capacity = capacity;
        }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Capacity: {Capacity}");
        }
    }
}
