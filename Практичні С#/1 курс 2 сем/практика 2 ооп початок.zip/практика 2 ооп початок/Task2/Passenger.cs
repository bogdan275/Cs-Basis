﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Passenger : Person
    {
        public string TicketNumber { get; set; }
        public Passenger(string name, int age, string ticketNumber) : base(name, age)
        {
            TicketNumber = ticketNumber;
        }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Ticket Number: {TicketNumber}");
        }
    }
}
