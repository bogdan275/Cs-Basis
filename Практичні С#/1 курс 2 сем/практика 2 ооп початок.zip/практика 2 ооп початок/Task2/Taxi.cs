﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Taxi : Vehicle
    {
        public string DriverName { get; set; }
        public Taxi(string licensePlate, string model, string driverName) : base(licensePlate, model)
        {
            DriverName = driverName;
        }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Driver Name: {DriverName}");
        }
    }
}
