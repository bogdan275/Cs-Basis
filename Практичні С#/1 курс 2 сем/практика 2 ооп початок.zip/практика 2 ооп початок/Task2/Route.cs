﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Route
    {
        public string StartLocation { get; set; }
        public string EndLocation { get; set; }
        public List<Vehicle> Vehicles { get; set; }
        public Route(string startLocation, string endLocation)
        {
            StartLocation = startLocation;
            EndLocation = endLocation;
            Vehicles = new List<Vehicle>();
        }
        public void AddVehicle(Vehicle vehicle)
        {
            Vehicles.Add(vehicle);
        }
    }
}
