﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Task2;
class Program
{
    static void Main()
    {

        Driver driver1 = new Driver("Ivan Ivanov", 40, "145b");
        Passenger passenger1 = new Passenger("Sergiy Melnuk", 28, "644a");
        Bus bus1 = new Bus("BK1945BK", "Mercedes", 30);
        Taxi taxi1 = new Taxi("DI1989IA", "Lanos", driver1.Name);
        Route route1 = new Route("Kiyiv", "Lviv");

        route1.AddVehicle(bus1);
        route1.AddVehicle(taxi1);

        Ticket ticket1 = new Ticket("1", passenger1, bus1);

        Schedule schedule1 = new Schedule(DateTime.Now, DateTime.Now.AddHours(7), bus1);

        Payment payment1 = new Payment("VISA", 20.0, "Credit Card");

        driver1.DisplayInfo();
        passenger1.DisplayInfo();
        bus1.DisplayInfo();
        taxi1.DisplayInfo();
    }
}


