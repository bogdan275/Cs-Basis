﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Payment
    {
        public string PaymentId { get; set; }
        public double Amount { get; set; }
        public string Method { get; set; }
        public Payment(string paymentId, double amount, string method)
        {
            PaymentId = paymentId;
            Amount = amount;
            Method = method;
        }
    }
}
