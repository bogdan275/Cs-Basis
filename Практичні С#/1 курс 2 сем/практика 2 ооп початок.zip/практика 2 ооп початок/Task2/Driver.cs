﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Driver : Person
    {
        public string LicenseNumber { get; set; }
        public Driver(string name, int age, string licenseNumber) : base(name, age)
        {
            LicenseNumber = licenseNumber;
        }
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"License Number: {LicenseNumber}");
        }
    }
}
