﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Schedule
    {
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public Vehicle Vehicle { get; set; }
        public Schedule(DateTime departureTime, DateTime arrivalTime, Vehicle vehicle)
        {
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            Vehicle = vehicle;
        }
    }
}
