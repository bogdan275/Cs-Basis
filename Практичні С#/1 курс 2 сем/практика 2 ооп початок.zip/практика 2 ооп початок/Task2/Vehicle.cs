﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task2
{
    class Vehicle
    {
        public string LicensePlate { get; set; }
        public string Model { get; set; }
        public Vehicle(string licensePlate, string model)
        {
            LicensePlate = licensePlate;
            Model = model;
        }
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"License Plate: {LicensePlate}, Model: {Model}");
        }
    }
}
