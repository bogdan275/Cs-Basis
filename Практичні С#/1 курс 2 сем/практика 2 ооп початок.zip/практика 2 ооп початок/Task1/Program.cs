﻿using System;

namespace Task1
{
    class OnlineCourse
    {

        private string courseName;
        private string author;
        private int yearCreated;
        private double duration; 
        private double price;
        private bool hasCertificate;

        public string CourseName
        {
            get { return courseName; }
            set { courseName = value; }
        }
        public string Author
        {
            get { return author; }
            set { author = value; }
        }
        public int YearCreated
        {
            get { return yearCreated; }
        }
        public double Price
        {
            get { return price; }
            set
            {
                if (value > 0)
                    price = value;
                else
                    return;
            }
        }


        public OnlineCourse(string courseName, string author, int yearCreated, double duration, double price)
        {
            this.courseName = courseName;
            this.author = author;
            this.yearCreated = yearCreated;
            this.duration = duration;
            this.Price = price; 
        }

        public OnlineCourse()
        {
            courseName = "Курс1";
            author = "Автор1";
            yearCreated = DateTime.Now.Year;
            duration = 0;
            price = 0;
        }

        public double CalculatePriceWithDiscount(double discountPercentage)
        {
            return price -= (price * discountPercentage / 100);
        }



        public bool IsCertificateAvailable()
        {
            if (yearCreated <= DateTime.Now.Year - 1)
            {
                hasCertificate = true;
            }
            else
            {
                hasCertificate = false;
            }
            return hasCertificate;
        }

        public void DisplayCourseInfo()
        {
            Console.WriteLine($"Назва: {courseName}");
            Console.WriteLine($"Автор: {author}");
            Console.WriteLine($"Рік створення: {yearCreated}");
            Console.WriteLine($"Тривалість: {duration}");
            Console.WriteLine($"Вартість: {price}");
        }

        public void UpdatePrice(double percentageIncrease = 25)
        {
            price -= price * percentageIncrease / 100;
            Console.WriteLine($"Ціна курсу {courseName} після оновлення: {price}");
        }
    }

    class Program
    {
        static void Main()
        {

            OnlineCourse course = new OnlineCourse("C# Programming", "Yuriy kleban", 2024, 700, 12000);
            OnlineCourse course2 = new OnlineCourse();
            OnlineCourse course3 = new OnlineCourse("English speaking", "Ivan Ivanov", 2022, 50, 1500);
            OnlineCourse course4 = new OnlineCourse("Hystory of Ukraine", "Petro Petrenko", 1991, 100, 200);


            course.DisplayCourseInfo();
            Console.WriteLine();
            course2.DisplayCourseInfo();
            Console.WriteLine();
            course3.DisplayCourseInfo();
            Console.WriteLine();


            double discountedPrice = course.CalculatePriceWithDiscount(10);
            double discountedPrice2 = course2.CalculatePriceWithDiscount(50);


            Console.WriteLine($"Ціна курсу {course.CourseName} після 10% знижки: {discountedPrice}");
            Console.WriteLine();
            Console.WriteLine($"Ціна курсу {course2.CourseName} після 50% знижки: {discountedPrice2}");
            Console.WriteLine();


            Console.WriteLine($"Статус курсу {course.CourseName} : {course.IsCertificateAvailable()}");


            course.UpdatePrice();
        }
    }
}
