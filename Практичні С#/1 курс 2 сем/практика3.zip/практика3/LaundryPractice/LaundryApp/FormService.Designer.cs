﻿namespace LaundryApp
{
    partial class FormService
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxServices = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxServiceEquipment = new System.Windows.Forms.ComboBox();
            this.comboBoxServiceMaterial = new System.Windows.Forms.ComboBox();
            this.numericUpDownServiceDuration = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonMaterialDelate = new System.Windows.Forms.Button();
            this.buttonMaterialSave = new System.Windows.Forms.Button();
            this.buttonMaterialClean = new System.Windows.Forms.Button();
            this.numericUpDownServicePrice = new System.Windows.Forms.NumericUpDown();
            this.textBoxServiceName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonServiceUpdate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownServiceDuration)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownServicePrice)).BeginInit();
            this.SuspendLayout();
            // 
            // listBoxServices
            // 
            this.listBoxServices.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBoxServices.FormattingEnabled = true;
            this.listBoxServices.ItemHeight = 16;
            this.listBoxServices.Location = new System.Drawing.Point(0, 0);
            this.listBoxServices.Name = "listBoxServices";
            this.listBoxServices.Size = new System.Drawing.Size(366, 450);
            this.listBoxServices.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonServiceUpdate);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.comboBoxServiceEquipment);
            this.groupBox1.Controls.Add(this.comboBoxServiceMaterial);
            this.groupBox1.Controls.Add(this.numericUpDownServiceDuration);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.buttonMaterialDelate);
            this.groupBox1.Controls.Add(this.buttonMaterialSave);
            this.groupBox1.Controls.Add(this.buttonMaterialClean);
            this.groupBox1.Controls.Add(this.numericUpDownServicePrice);
            this.groupBox1.Controls.Add(this.textBoxServiceName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(388, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 426);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Materials operator";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 110);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Equipment";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(185, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 16);
            this.label4.TabIndex = 11;
            this.label4.Text = "Material";
            // 
            // comboBoxServiceEquipment
            // 
            this.comboBoxServiceEquipment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxServiceEquipment.FormattingEnabled = true;
            this.comboBoxServiceEquipment.Location = new System.Drawing.Point(38, 129);
            this.comboBoxServiceEquipment.Name = "comboBoxServiceEquipment";
            this.comboBoxServiceEquipment.Size = new System.Drawing.Size(121, 24);
            this.comboBoxServiceEquipment.TabIndex = 10;
            // 
            // comboBoxServiceMaterial
            // 
            this.comboBoxServiceMaterial.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxServiceMaterial.FormattingEnabled = true;
            this.comboBoxServiceMaterial.Location = new System.Drawing.Point(188, 129);
            this.comboBoxServiceMaterial.Name = "comboBoxServiceMaterial";
            this.comboBoxServiceMaterial.Size = new System.Drawing.Size(121, 24);
            this.comboBoxServiceMaterial.TabIndex = 9;
            // 
            // numericUpDownServiceDuration
            // 
            this.numericUpDownServiceDuration.Location = new System.Drawing.Point(188, 192);
            this.numericUpDownServiceDuration.Name = "numericUpDownServiceDuration";
            this.numericUpDownServiceDuration.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownServiceDuration.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(185, 173);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Duration";
            // 
            // buttonMaterialDelate
            // 
            this.buttonMaterialDelate.Location = new System.Drawing.Point(305, 386);
            this.buttonMaterialDelate.Name = "buttonMaterialDelate";
            this.buttonMaterialDelate.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialDelate.TabIndex = 6;
            this.buttonMaterialDelate.Text = "Delate";
            this.buttonMaterialDelate.UseVisualStyleBackColor = true;
            this.buttonMaterialDelate.Click += new System.EventHandler(this.buttonMaterialDelate_Click);
            // 
            // buttonMaterialSave
            // 
            this.buttonMaterialSave.Location = new System.Drawing.Point(188, 265);
            this.buttonMaterialSave.Name = "buttonMaterialSave";
            this.buttonMaterialSave.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialSave.TabIndex = 5;
            this.buttonMaterialSave.Text = "Save";
            this.buttonMaterialSave.UseVisualStyleBackColor = true;
            this.buttonMaterialSave.Click += new System.EventHandler(this.buttonMaterialSave_Click);
            // 
            // buttonMaterialClean
            // 
            this.buttonMaterialClean.Location = new System.Drawing.Point(38, 265);
            this.buttonMaterialClean.Name = "buttonMaterialClean";
            this.buttonMaterialClean.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialClean.TabIndex = 4;
            this.buttonMaterialClean.Text = "Clean";
            this.buttonMaterialClean.UseVisualStyleBackColor = true;
            // 
            // numericUpDownServicePrice
            // 
            this.numericUpDownServicePrice.Location = new System.Drawing.Point(188, 62);
            this.numericUpDownServicePrice.Name = "numericUpDownServicePrice";
            this.numericUpDownServicePrice.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownServicePrice.TabIndex = 3;
            // 
            // textBoxServiceName
            // 
            this.textBoxServiceName.Location = new System.Drawing.Point(38, 63);
            this.textBoxServiceName.Name = "textBoxServiceName";
            this.textBoxServiceName.Size = new System.Drawing.Size(141, 22);
            this.textBoxServiceName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Price ($)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // buttonServiceUpdate
            // 
            this.buttonServiceUpdate.Location = new System.Drawing.Point(38, 328);
            this.buttonServiceUpdate.Name = "buttonServiceUpdate";
            this.buttonServiceUpdate.Size = new System.Drawing.Size(89, 34);
            this.buttonServiceUpdate.TabIndex = 13;
            this.buttonServiceUpdate.Text = "Update";
            this.buttonServiceUpdate.UseVisualStyleBackColor = true;
            this.buttonServiceUpdate.Click += new System.EventHandler(this.buttonServiceUpdate_Click);
            // 
            // FormService
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBoxServices);
            this.Name = "FormService";
            this.Text = "FormService";
            this.Load += new System.EventHandler(this.FormService_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownServiceDuration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownServicePrice)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxServices;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonMaterialDelate;
        private System.Windows.Forms.Button buttonMaterialSave;
        private System.Windows.Forms.Button buttonMaterialClean;
        private System.Windows.Forms.NumericUpDown numericUpDownServicePrice;
        private System.Windows.Forms.TextBox textBoxServiceName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDownServiceDuration;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxServiceEquipment;
        private System.Windows.Forms.ComboBox comboBoxServiceMaterial;
        private System.Windows.Forms.Button buttonServiceUpdate;
    }
}