﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class Form1 : Form
    {
        EquipmentManager equipmentManager = new EquipmentManager();
        MaterialManager materialManager = new MaterialManager();
        ServiceManager serviceManager;
        ClientManager clientManager;
        OrdersManager ordersManager;

        public Form1()
        {
            InitializeComponent();
            serviceManager = new ServiceManager(equipmentManager, materialManager);
            clientManager = new ClientManager(serviceManager.GetServices());
            ordersManager = new OrdersManager(clientManager, serviceManager);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateMaterialList();
            UpdateClientsList();
            UpdateEquipmentList();
            UpdateServiceList();
            UpdateOrdersList();
        }

        private void UpdateEquipmentList()
        {
            listBoxEquipment.Items.Clear();
            listBoxEquipment.Items.AddRange(equipmentManager.GetEquipments().ToArray());
        }

        private void UpdateMaterialList()
        {
            listBoxMaterial.Items.Clear();
            listBoxMaterial.Items.AddRange(materialManager.GetMaterials().ToArray());
        }

        private void UpdateServiceList()
        {
            listBoxService.Items.Clear();
            listBoxService.Items.AddRange(serviceManager.GetServices().ToArray());
        }

        private void UpdateClientsList()
        {
            listBoxEquipment.Items.Clear();
            listBoxClient.Items.AddRange(clientManager.GetClients().ToArray());
        }

        private void UpdateOrdersList()
        {
            listBoxOrders.Items.Clear();
            listBoxOrders.Items.AddRange(ordersManager.GetOrders().ToArray());
        }

        private void createMateriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var materialForm = new FormMaterial(materialManager);
            materialForm.Show();
            materialForm.FormClosed += (s, args) =>
            {
                UpdateMaterialList();
            };
            materialForm.Show();

        }
        private void createEquipmentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var equipmentForm = new FormEquipment(equipmentManager);
            equipmentForm.Show();
            equipmentForm.FormClosed += (s, args) =>
            {
                UpdateEquipmentList();
            };
            equipmentForm.Show();
        }
        private void createClientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var clientForm = new FormClient(clientManager, serviceManager);
            clientForm.Show();
            clientForm.FormClosed += (s, args) =>
            {
                UpdateClientsList();
            };
            clientForm.Show();
        }

        private void createServiceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var serviceForm = new FormService(serviceManager, equipmentManager, materialManager);
            serviceForm.Show();
            serviceForm.FormClosed += (s, args) =>
            {
                UpdateServiceList();
            };
            serviceForm.Show();
        }

        private void financialReportsToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var reportsForm = new FormReports();
            reportsForm.Show();
        }
    }
}

