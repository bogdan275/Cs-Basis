﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class FormService : Form
    {
        private ServiceManager serviceManager;
        private EquipmentManager equipmentManager;
        private MaterialManager materialManager;
        public FormService(ServiceManager serviceManager, EquipmentManager equipmentManager)
        {
            InitializeComponent();
            this.serviceManager = serviceManager;
        }

        public FormService(ServiceManager serviceManager, EquipmentManager equipmentManager, MaterialManager materialManager)  
        {
            InitializeComponent();
            serviceManager.GetServices();
            this.serviceManager = serviceManager;
            this.equipmentManager = equipmentManager;
            this.materialManager = materialManager;
        }


        private void FormService_Load(object sender, EventArgs e)
        {
            UpdateServiceList();
            comboBoxServiceEquipment.Items.AddRange(equipmentManager.GetEquipments().ToArray());
            comboBoxServiceMaterial.Items.AddRange(materialManager.GetMaterials().ToArray());
            comboBoxServiceEquipment.SelectedIndex = 0;
            comboBoxServiceMaterial.SelectedIndex = 0;
        }

        private void UpdateServiceList()
        {
            listBoxServices.Items.Clear();
            listBoxServices.Items.AddRange(serviceManager.GetServices().ToArray());
        }

        private void buttonServiceClean_Click(object sender, EventArgs e)
        {
            textBoxServiceName.Clear();
            numericUpDownServicePrice.Value = 0;
            numericUpDownServiceDuration.Value = 0;
            comboBoxServiceEquipment.SelectedIndex = 0;
            comboBoxServiceMaterial.SelectedIndex = 0;
        }

        private void buttonMaterialSave_Click(object sender, EventArgs e)
        {
            string name = textBoxServiceName.Text;
            int price = (int)numericUpDownServicePrice.Value;
            int duration = (int)numericUpDownServiceDuration.Value;
            Equipment equipment = (Equipment)comboBoxServiceEquipment.SelectedItem;
            Material material = (Material)comboBoxServiceMaterial.SelectedItem;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a service name.");
                return;
            }
            if (price <= 0)
            {
                MessageBox.Show("Please enter a valid price.");
                return;
            }
            if (duration <= 0)
            {
                MessageBox.Show("Please enter a valid duration.");
                return;
            }
            Service newService = new Service(name, price, duration, equipment, material);
            serviceManager.AddService(newService);
            UpdateServiceList();
        }

        private void buttonMaterialDelate_Click(object sender, EventArgs e)
        {
            Service selectedService = (Service)listBoxServices.SelectedItem;
            if (selectedService != null)
            {
                serviceManager.RemoveService(selectedService);
                UpdateServiceList();
            }
            else
            {
                MessageBox.Show("Please select a service to delete.");
            }
        }

        private void buttonServiceUpdate_Click(object sender, EventArgs e)
        {
            Service selectedService = (Service)listBoxServices.SelectedItem;
            if (selectedService == null)
            {
                MessageBox.Show("Please select a service to update.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            else 
            {
                textBoxServiceName.Text = selectedService.Name;
                numericUpDownServicePrice.Value = selectedService.Price;
                numericUpDownServiceDuration.Value = selectedService.Duration;
                comboBoxServiceEquipment.SelectedItem = selectedService.EquipmentServiceNeeded;
                comboBoxServiceMaterial.SelectedItem = selectedService.MaterialServiceNeeded;

                string name = textBoxServiceName.Text;
                int price = (int)numericUpDownServicePrice.Value;
                int duration = (int)numericUpDownServiceDuration.Value;
                Equipment equipment = (Equipment)comboBoxServiceEquipment.SelectedItem;
                Material material = (Material)comboBoxServiceMaterial.SelectedItem;
                if (string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Please enter a service name.");
                    return;
                }
                if (price <= 0)
                {
                    MessageBox.Show("Please enter a valid price.");
                    return;
                }
                if (duration <= 0)
                {
                    MessageBox.Show("Please enter a valid duration.");
                    return;
                }
                selectedService.Name = name;
                selectedService.Price = price;
                selectedService.Duration = duration;
                selectedService.EquipmentServiceNeeded = equipment;
                selectedService.MaterialServiceNeeded = material;
                UpdateServiceList();
            }


        }
    }
}
