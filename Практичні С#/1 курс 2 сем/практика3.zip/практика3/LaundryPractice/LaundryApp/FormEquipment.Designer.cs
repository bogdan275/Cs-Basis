﻿namespace LaundryApp
{
    partial class FormEquipment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxEquipments = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonMaterialDelate = new System.Windows.Forms.Button();
            this.buttonMaterialSave = new System.Windows.Forms.Button();
            this.buttonMaterialClean = new System.Windows.Forms.Button();
            this.numericUpDownMaterialQuantity = new System.Windows.Forms.NumericUpDown();
            this.textBoxMaterialName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonEquipmentUpdate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMaterialQuantity)).BeginInit();
            this.SuspendLayout();
            // 
            // listBoxEquipments
            // 
            this.listBoxEquipments.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBoxEquipments.ItemHeight = 16;
            this.listBoxEquipments.Location = new System.Drawing.Point(0, 0);
            this.listBoxEquipments.Name = "listBoxEquipments";
            this.listBoxEquipments.Size = new System.Drawing.Size(374, 450);
            this.listBoxEquipments.TabIndex = 13;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonEquipmentUpdate);
            this.groupBox1.Controls.Add(this.buttonMaterialDelate);
            this.groupBox1.Controls.Add(this.buttonMaterialSave);
            this.groupBox1.Controls.Add(this.buttonMaterialClean);
            this.groupBox1.Controls.Add(this.numericUpDownMaterialQuantity);
            this.groupBox1.Controls.Add(this.textBoxMaterialName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(388, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 376);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Equipment operator";
            // 
            // buttonMaterialDelate
            // 
            this.buttonMaterialDelate.Location = new System.Drawing.Point(38, 336);
            this.buttonMaterialDelate.Name = "buttonMaterialDelate";
            this.buttonMaterialDelate.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialDelate.TabIndex = 6;
            this.buttonMaterialDelate.Text = "Delate";
            this.buttonMaterialDelate.UseVisualStyleBackColor = true;
            this.buttonMaterialDelate.Click += new System.EventHandler(this.buttonMaterialDelate_Click);
            // 
            // buttonMaterialSave
            // 
            this.buttonMaterialSave.Location = new System.Drawing.Point(188, 126);
            this.buttonMaterialSave.Name = "buttonMaterialSave";
            this.buttonMaterialSave.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialSave.TabIndex = 5;
            this.buttonMaterialSave.Text = "Save";
            this.buttonMaterialSave.UseVisualStyleBackColor = true;
            this.buttonMaterialSave.Click += new System.EventHandler(this.buttonMaterialSave_Click);
            // 
            // buttonMaterialClean
            // 
            this.buttonMaterialClean.Location = new System.Drawing.Point(38, 126);
            this.buttonMaterialClean.Name = "buttonMaterialClean";
            this.buttonMaterialClean.Size = new System.Drawing.Size(89, 34);
            this.buttonMaterialClean.TabIndex = 4;
            this.buttonMaterialClean.Text = "Clean";
            this.buttonMaterialClean.UseVisualStyleBackColor = true;
            this.buttonMaterialClean.Click += new System.EventHandler(this.buttonMaterialClean_Click);
            // 
            // numericUpDownMaterialQuantity
            // 
            this.numericUpDownMaterialQuantity.Location = new System.Drawing.Point(188, 62);
            this.numericUpDownMaterialQuantity.Name = "numericUpDownMaterialQuantity";
            this.numericUpDownMaterialQuantity.Size = new System.Drawing.Size(120, 22);
            this.numericUpDownMaterialQuantity.TabIndex = 3;
            // 
            // textBoxMaterialName
            // 
            this.textBoxMaterialName.Location = new System.Drawing.Point(38, 63);
            this.textBoxMaterialName.Name = "textBoxMaterialName";
            this.textBoxMaterialName.Size = new System.Drawing.Size(141, 22);
            this.textBoxMaterialName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Quantity (Kg)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // buttonEquipmentUpdate
            // 
            this.buttonEquipmentUpdate.Location = new System.Drawing.Point(38, 192);
            this.buttonEquipmentUpdate.Name = "buttonEquipmentUpdate";
            this.buttonEquipmentUpdate.Size = new System.Drawing.Size(89, 34);
            this.buttonEquipmentUpdate.TabIndex = 7;
            this.buttonEquipmentUpdate.Text = "update";
            this.buttonEquipmentUpdate.UseVisualStyleBackColor = true;
            this.buttonEquipmentUpdate.Click += new System.EventHandler(this.buttonEquipmentUpdate_Click);
            // 
            // FormEquipment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBoxEquipments);
            this.Name = "FormEquipment";
            this.Text = "FormEquipment";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownMaterialQuantity)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxEquipments;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonMaterialDelate;
        private System.Windows.Forms.Button buttonMaterialSave;
        private System.Windows.Forms.Button buttonMaterialClean;
        private System.Windows.Forms.NumericUpDown numericUpDownMaterialQuantity;
        private System.Windows.Forms.TextBox textBoxMaterialName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonEquipmentUpdate;
    }
}