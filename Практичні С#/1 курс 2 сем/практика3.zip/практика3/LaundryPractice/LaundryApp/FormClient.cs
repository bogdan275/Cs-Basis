﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class FormClient : Form
    {
        private ClientManager clientManager;
        private ServiceManager serviceManager;
        private EquipmentManager equipmentManager;
        private MaterialManager materialManager;
        public FormClient(ClientManager clientManager, ServiceManager serviceManager)
        {
            InitializeComponent();
            this.clientManager = clientManager;
            this.serviceManager = serviceManager;
        }

        public FormClient()
        {
            InitializeComponent();
            clientManager.GetClients();
        }

        private void FormClient_Load(object sender, EventArgs e)
        {
            UpdateClientList();
            comboBoxClientService.Items.AddRange(serviceManager.GetServices().ToArray());
        }
        private void UpdateClientList()
        {
            listBoxClient.Items.Clear();
            listBoxClient.Items.AddRange(clientManager.GetClients().ToArray());
        }

        private void buttonClientClean_Click(object sender, EventArgs e)
        {
            textBoxClientName.Clear();
            comboBoxClientService.SelectedIndex = 0;
        }

        private void buttonClientClean_Click_1(object sender, EventArgs e)
        {
            textBoxClientName.Clear();
            comboBoxClientService.SelectedIndex = 0;
        }

        private void buttonClientSave_Click(object sender, EventArgs e)
        {
            string name = textBoxClientName.Text;
            Service selectedService = comboBoxClientService.SelectedItem as Service;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a client name.");
                return;
            }
            if (selectedService == null)
            {
                MessageBox.Show("Please select a service.");
                return;
            }
            Client newClient = new Client(name, selectedService);
            clientManager.AddClient(newClient);
            UpdateClientList();
        }

        private void buttonClientDelate_Click(object sender, EventArgs e)
        {
            if (listBoxClient.SelectedItem != null)
            {
                Client selectedClient = listBoxClient.SelectedItem as Client;
                clientManager.RemoveClient(selectedClient);
                UpdateClientList();
            }
            else
            {
                MessageBox.Show("Please select a client to delete.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
            }
        }

        private void buttonClientUpdate_Click(object sender, EventArgs e)
        {

            if (listBoxClient.SelectedItem == null)
            {
                MessageBox.Show("Please select a client to update.");
            }
            else
            {
                Client selectedClient = listBoxClient.SelectedItem as Client;
                string name = textBoxClientName.Text;
                Service selectedService = comboBoxClientService.SelectedItem as Service;
                if (string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Please enter a client name.");
                    return;
                }
                if (selectedService == null)
                {
                    MessageBox.Show("Please select a service.");
                    return;
                }
                selectedClient.Name = name;
                selectedClient.Service = selectedService;
                UpdateClientList();
            }
        }
    }
}
