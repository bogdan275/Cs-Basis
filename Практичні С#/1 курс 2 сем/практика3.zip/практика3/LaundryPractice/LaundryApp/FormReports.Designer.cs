﻿namespace LaundryApp
{
    partial class FormReports
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxReportsByUser = new System.Windows.Forms.ListBox();
            this.comboBoxUserNames = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCreatereport = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBoxReportsByUser
            // 
            this.listBoxReportsByUser.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBoxReportsByUser.FormattingEnabled = true;
            this.listBoxReportsByUser.ItemHeight = 16;
            this.listBoxReportsByUser.Location = new System.Drawing.Point(0, 0);
            this.listBoxReportsByUser.Name = "listBoxReportsByUser";
            this.listBoxReportsByUser.Size = new System.Drawing.Size(442, 636);
            this.listBoxReportsByUser.TabIndex = 0;
            // 
            // comboBoxUserNames
            // 
            this.comboBoxUserNames.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxUserNames.FormattingEnabled = true;
            this.comboBoxUserNames.Location = new System.Drawing.Point(465, 69);
            this.comboBoxUserNames.Name = "comboBoxUserNames";
            this.comboBoxUserNames.Size = new System.Drawing.Size(268, 24);
            this.comboBoxUserNames.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(462, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 16);
            this.label1.TabIndex = 11;
            this.label1.Text = "Chose User";
            // 
            // buttonCreatereport
            // 
            this.buttonCreatereport.Location = new System.Drawing.Point(465, 124);
            this.buttonCreatereport.Name = "buttonCreatereport";
            this.buttonCreatereport.Size = new System.Drawing.Size(103, 44);
            this.buttonCreatereport.TabIndex = 12;
            this.buttonCreatereport.Text = "Create";
            this.buttonCreatereport.UseVisualStyleBackColor = true;
            // 
            // FormReports
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(998, 636);
            this.Controls.Add(this.buttonCreatereport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxUserNames);
            this.Controls.Add(this.listBoxReportsByUser);
            this.Name = "FormReports";
            this.Text = "FormReports";
            this.Load += new System.EventHandler(this.FormReports_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxReportsByUser;
        private System.Windows.Forms.ComboBox comboBoxUserNames;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCreatereport;
    }
}