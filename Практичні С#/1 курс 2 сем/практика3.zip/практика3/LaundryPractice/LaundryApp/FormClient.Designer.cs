﻿namespace LaundryApp
{
    partial class FormClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxClient = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBoxClientService = new System.Windows.Forms.ComboBox();
            this.buttonClientDelate = new System.Windows.Forms.Button();
            this.buttonClientSave = new System.Windows.Forms.Button();
            this.buttonClientClean = new System.Windows.Forms.Button();
            this.textBoxClientName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonClientUpdate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxClient
            // 
            this.listBoxClient.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBoxClient.FormattingEnabled = true;
            this.listBoxClient.ItemHeight = 16;
            this.listBoxClient.Location = new System.Drawing.Point(0, 0);
            this.listBoxClient.Name = "listBoxClient";
            this.listBoxClient.Size = new System.Drawing.Size(366, 450);
            this.listBoxClient.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonClientUpdate);
            this.groupBox1.Controls.Add(this.comboBoxClientService);
            this.groupBox1.Controls.Add(this.buttonClientDelate);
            this.groupBox1.Controls.Add(this.buttonClientSave);
            this.groupBox1.Controls.Add(this.buttonClientClean);
            this.groupBox1.Controls.Add(this.textBoxClientName);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(372, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 376);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Client operator";
            // 
            // comboBoxClientService
            // 
            this.comboBoxClientService.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxClientService.FormattingEnabled = true;
            this.comboBoxClientService.Location = new System.Drawing.Point(188, 60);
            this.comboBoxClientService.Name = "comboBoxClientService";
            this.comboBoxClientService.Size = new System.Drawing.Size(121, 24);
            this.comboBoxClientService.TabIndex = 7;
            // 
            // buttonClientDelate
            // 
            this.buttonClientDelate.Location = new System.Drawing.Point(38, 336);
            this.buttonClientDelate.Name = "buttonClientDelate";
            this.buttonClientDelate.Size = new System.Drawing.Size(89, 34);
            this.buttonClientDelate.TabIndex = 6;
            this.buttonClientDelate.Text = "Delate";
            this.buttonClientDelate.UseVisualStyleBackColor = true;
            this.buttonClientDelate.Click += new System.EventHandler(this.buttonClientDelate_Click);
            // 
            // buttonClientSave
            // 
            this.buttonClientSave.Location = new System.Drawing.Point(188, 126);
            this.buttonClientSave.Name = "buttonClientSave";
            this.buttonClientSave.Size = new System.Drawing.Size(89, 34);
            this.buttonClientSave.TabIndex = 5;
            this.buttonClientSave.Text = "Save";
            this.buttonClientSave.UseVisualStyleBackColor = true;
            this.buttonClientSave.Click += new System.EventHandler(this.buttonClientSave_Click);
            // 
            // buttonClientClean
            // 
            this.buttonClientClean.Location = new System.Drawing.Point(38, 126);
            this.buttonClientClean.Name = "buttonClientClean";
            this.buttonClientClean.Size = new System.Drawing.Size(89, 34);
            this.buttonClientClean.TabIndex = 4;
            this.buttonClientClean.Text = "Clean";
            this.buttonClientClean.UseVisualStyleBackColor = true;
            this.buttonClientClean.Click += new System.EventHandler(this.buttonClientClean_Click_1);
            // 
            // textBoxClientName
            // 
            this.textBoxClientName.Location = new System.Drawing.Point(38, 63);
            this.textBoxClientName.Name = "textBoxClientName";
            this.textBoxClientName.Size = new System.Drawing.Size(141, 22);
            this.textBoxClientName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 43);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Service";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Name";
            // 
            // buttonClientUpdate
            // 
            this.buttonClientUpdate.Location = new System.Drawing.Point(38, 193);
            this.buttonClientUpdate.Name = "buttonClientUpdate";
            this.buttonClientUpdate.Size = new System.Drawing.Size(89, 34);
            this.buttonClientUpdate.TabIndex = 8;
            this.buttonClientUpdate.Text = "Update";
            this.buttonClientUpdate.UseVisualStyleBackColor = true;
            this.buttonClientUpdate.Click += new System.EventHandler(this.buttonClientUpdate_Click);
            // 
            // FormClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.listBoxClient);
            this.Name = "FormClient";
            this.Text = "FormClient";
            this.Load += new System.EventHandler(this.FormClient_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBoxClient;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonClientDelate;
        private System.Windows.Forms.Button buttonClientSave;
        private System.Windows.Forms.Button buttonClientClean;
        private System.Windows.Forms.TextBox textBoxClientName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxClientService;
        private System.Windows.Forms.Button buttonClientUpdate;
    }
}