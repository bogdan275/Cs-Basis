﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class FormMaterial : Form
    {
        private MaterialManager materialManager;
        public FormMaterial(MaterialManager materialManager)
        {
            InitializeComponent();
            this.materialManager = materialManager;
        }

        public FormMaterial()
        {
            InitializeComponent();
            materialManager.GetMaterials();
        }

        private void FormMaterial_Load(object sender, EventArgs e)
        {
            UpdateMaterialList();
        }

        private void UpdateMaterialList()
        {
            listBoxMaterials.Items.Clear();
            listBoxMaterials.Items.AddRange(materialManager.GetMaterials().ToArray());
        }

        private void buttonMaterialClean_Click(object sender, EventArgs e)
        {
            textBoxMaterialName.Clear();
            numericUpDownMaterialQuantity.Value = 1;
        }

        private void buttonMaterialSave_Click(object sender, EventArgs e)
        {
            string name = textBoxMaterialName.Text;
            int quantity = (int)numericUpDownMaterialQuantity.Value;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a material name.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            if (quantity == 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            Material newMaterial = new Material(name, quantity);
            materialManager.AddMaterial(newMaterial);
            UpdateMaterialList();
        }

        private void buttonMaterialDelate_Click(object sender, EventArgs e)
        {
            if (listBoxMaterials.SelectedItem == null)
            {
                MessageBox.Show("Please select a material to remove.", "error");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            Material selectedMaterial = (Material)listBoxMaterials.SelectedItem;
            materialManager.RemoveMaterial(selectedMaterial);
            UpdateMaterialList();
        }

        private void buttonMaterialUpdate_Click(object sender, EventArgs e)
        {
            if (listBoxMaterials.SelectedItem == null)
            {
                MessageBox.Show("Please select a material to update.", "error");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            Material selectedMaterial = (Material)listBoxMaterials.SelectedItem;
            string name = textBoxMaterialName.Text;
            int quantity = (int)numericUpDownMaterialQuantity.Value;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a material name.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            if (quantity == 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            selectedMaterial.Name = name;
            selectedMaterial.Quantity = quantity;
            textBoxMaterialName.Clear();
            numericUpDownMaterialQuantity.Value = 1;
            UpdateMaterialList();
        }
    }
}
