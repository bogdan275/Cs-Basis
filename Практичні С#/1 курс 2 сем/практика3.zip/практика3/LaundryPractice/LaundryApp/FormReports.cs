﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class FormReports : Form
    {
        private LaundryManager laundryManager;
        public FormReports(Laundry laundry)
        {
            InitializeComponent();
            this.laundryManager = laundryManager;
        }

        public FormReports()
        {
            InitializeComponent();
            laundryManager = new LaundryManager(new EquipmentManager(), new MaterialManager(), new ServiceManager(), new ClientManager());
        }

        private void FormReports_Load(object sender, EventArgs e)
        {
            listBoxReportsByUser.Items.AddRange(laundryManager.GetLaundries().ToArray());
            UpdateReportList();
        }

        private void UpdateReportList()
        {
            listBoxReportsByUser.Items.Clear();
            listBoxReportsByUser.Items.AddRange(laundryManager.GetLaundries().ToArray());
        }
    }
}
