﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LaundryApp.BaseClasses;
using LaundryApp.Operators;

namespace LaundryApp
{
    public partial class FormEquipment : Form
    {
        private EquipmentManager equipmentManager;
        public FormEquipment(EquipmentManager equipmentManager)
        {
            InitializeComponent();
            this.equipmentManager = equipmentManager;
        }
        public FormEquipment()
        {
            InitializeComponent();
            equipmentManager.GetEquipments();
        }

        private void FormEquipment_Load(object sender, EventArgs e)
        {
            UpdateEquipmentList();
        }

        private void UpdateEquipmentList()
        {
            listBoxEquipments.Items.Clear();
            listBoxEquipments.Items.AddRange(equipmentManager.GetEquipments().ToArray());
        }

        private void buttonMaterialClean_Click(object sender, EventArgs e)
        {
            textBoxMaterialName.Clear();
            numericUpDownMaterialQuantity.Value = 1;
        }

        private void buttonMaterialSave_Click(object sender, EventArgs e)
        {
            string name = textBoxMaterialName.Text;
            int quantity = (int)numericUpDownMaterialQuantity.Value;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a material name.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            if (quantity == 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                return;
            }
            Equipment newEquipment = new Equipment(name, quantity);
            equipmentManager.AddEquipment(newEquipment);
            UpdateEquipmentList();
        }

        private void buttonMaterialDelate_Click(object sender, EventArgs e)
        {
            if (listBoxEquipments.SelectedItem == null)
            {
                MessageBox.Show("Please select an equipment to delete.");
                return;
            }
            Equipment selectedEquipment = (Equipment)listBoxEquipments.SelectedItem;
            equipmentManager.RemoveEquipment(selectedEquipment);
            UpdateEquipmentList();

        }

        private void buttonEquipmentUpdate_Click(object sender, EventArgs e)
        {
            if (listBoxEquipments.SelectedItem == null)
            {
                MessageBox.Show("Please select an equipment to update.");
                return;
            }
            Equipment selectedEquipment = (Equipment)listBoxEquipments.SelectedItem;
            string name = textBoxMaterialName.Text;
            int quantity = (int)numericUpDownMaterialQuantity.Value;
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a material name.");
                return;
            }
            if (quantity == 0)
            {
                MessageBox.Show("Please enter a valid quantity.");
                return;
            }
            selectedEquipment.Name = name;
            selectedEquipment.Quantity = quantity;
            UpdateEquipmentList();
        }
    }
}
