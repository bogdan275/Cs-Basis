﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundryApp.BaseClasses
{
    public class Service
    {
        public string Name { get; set; }
        public int Price { get; set; }
        public int Duration { get; set; } = 40; // in minutes
        public Equipment EquipmentServiceNeeded { get; set; }
        public Material MaterialServiceNeeded { get; set; }

        public Service(string name, int price, int duration, Equipment equipment, Material materials) 
        { 
            Name = name;
            Price = price;
            Duration = duration;
            EquipmentServiceNeeded = equipment;
            MaterialServiceNeeded = materials;
        }

        public override string ToString()
        {
            return $"{Name} ({Price})";
        }
    }
}
