﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundryApp.BaseClasses
{
    public class Material
    {
        public string Name { get; set; }
        public int Quantity { get; set; } = 1;
        public Material(string name, int quantity)
        {
            Name = name;
            Quantity = quantity;
        }
        public override string ToString()
        {
            return $"{Name}, quantity:{Quantity}";
        }

    }
}
