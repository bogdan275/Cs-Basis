﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.Operators;

namespace LaundryApp.BaseClasses
{
    public class Order
    {
        public Service Service { get; set; }

        public Client Client { get; set; }

        public DateTime StartTime { get; set; } = DateTime.Now;

        public DateTime EndTime { get { return DateTime.Now.AddMinutes(Service.Duration); } }

        public string OrderStatus
        {
            get
            {
                if (EndTime < DateTime.Now)
                    return Helper.Statuses[2];
                else if (StartTime > DateTime.Now)
                    return Helper.Statuses[0];
                else
                    return Helper.Statuses[1];
            }
        }

        public Order(Service service, Client client, DateTime starttime)
        {
            Service = service;
            Client = client;
            StartTime = starttime;
        }

        public Order(Client client, Service service)
        {
            Client = client;
            Service = service;
        }

        public override string ToString()
        {
            return $"Order: {Service.Name} for {Client.Name}, time: [{StartTime.ToString("dd-HH-mm")}-" +
                $"{EndTime.ToString("dd-HH-mm")}], status: {OrderStatus}";
        }
    }
}
