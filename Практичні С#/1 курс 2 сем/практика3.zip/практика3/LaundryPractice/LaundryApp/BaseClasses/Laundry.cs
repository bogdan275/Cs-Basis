﻿using System;
using System.Collections.Generic;
using System.Linq;
using LaundryApp.Operators;

namespace LaundryApp.BaseClasses
{
    public class Laundry
    {
        private Equipment equipment;
        private Material material;
        private Service service;
        private Client client;

        public string Name { get; set; }
        public List<Equipment> Equipment { get; set; }
        public List<Material> Material { get; set; }
        public List<Service> Service { get; set; }
        public List<Client> Client { get; set; }

        
        public Laundry(string name, List<Equipment> equipment,
            List<Material> material,
            List<Service> service,
            List<Client> client)
        {
            Name = name;
            Equipment = equipment;
            Material = material;
            Service = service;
            Client = client;
        }

        public Laundry(string name, Equipment equipment, Material material, Service service, Client client)
        {
            Name = name;
            this.equipment = equipment;
            this.material = material;
            this.service = service;
            this.client = client;
        }

        public override string ToString()
        {
            return $"Laundry: {Name}";
        }

    }
}
