﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LaundryApp.BaseClasses
{
    public class Client
    {
        private Service selectedService;

        public string Name { get; set; }

        public Service Service{ get; set; }

        public int TotalMoneySpent
        { 
            get 
            { 
                return Service.Price;
            } 
        }

        public Client(string name, Service service) 
        { 
            Name = name;
            Service = service;
        }


        public override string ToString()
        {
            return $"{Name} (used: {Service.Name}, he spend: ${TotalMoneySpent} )";
        }

    }
}
