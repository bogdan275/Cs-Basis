﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class MaterialManager
    {
        public List<Material> materials;

        public MaterialManager()
        {
            materials = new List<Material>();
            GenerateMaterials();
        }

        public void AddMaterial(Material material)
        {
            materials.Add(material);
        }
        public void RemoveMaterial(Material material)
        {
            materials.Remove(material);
        }
        public List<Material> GetMaterials()
        {
            return materials;
        }
        private void GenerateMaterials()
        {
            materials.Add(new Material("Detergent", 10));
            materials.Add(new Material("Fabric Softener", 10));
            materials.Add(new Material("Bleach", 10));
            materials.Add(new Material("Stain Remover", 10));
            materials.Add(new Material("Laundry Bags", 10));
            materials.Add(new Material("Dryer Sheets", 10));
            materials.Add(new Material("Lint Roller", 10));
        }
    }
}
