﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class ServiceManager
    {   
        private List<Equipment> equipments;
        private List<Material> materials;
        private List<Service> services;

        private EquipmentManager equipmentManager;
        private MaterialManager materialManager;

        public List<Service> Services
        {
            get { return services; }
            set { services = value; }
        }

        public ServiceManager(EquipmentManager equipmentManager, MaterialManager materialManager)
        {
            this.equipmentManager = equipmentManager;
            this.materialManager = materialManager;
            services = new List<Service>();
            GenerateServices();
        }

        public ServiceManager()
        {
        }

        private void GenerateServices()
        {
            equipments = equipmentManager.GetEquipments();
            materials = materialManager.GetMaterials();

            services.Add(new Service("Washing", 10, 40, equipments[0], materials[0]));
            services.Add(new Service("Drying", 10, 40, equipments[1], materials[1]));
            services.Add(new Service("Ironing", 10, 40, equipments[2], materials[2]));
            services.Add(new Service("Folding", 10, 40, equipments[3], materials[3]));
            services.Add(new Service("Drying Rack", 10, 40, equipments[4], materials[4]));
            services.Add(new Service("Laundry Basket", 10, 40, equipments[5], materials[5]));
            services.Add(new Service("Detergent Dispenser", 10, 40, equipments[6], materials[6]));
        }
        public void AddService(Service service)
        {
            services.Add(service);
        }

        public void RemoveService(Service service)
        {
            services.Remove(service);
        }

        public List<Service> GetServices()
        {
            return services;
        }
    }
}
