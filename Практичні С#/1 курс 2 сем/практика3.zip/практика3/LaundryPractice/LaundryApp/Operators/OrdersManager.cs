﻿using System;
using System.Collections.Generic;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class OrdersManager
    {
        private List<Order> orders;

        private Client client;
        private Service service;

        private ClientManager clientManager;
        private ServiceManager serviceManager;

        public OrdersManager(ClientManager clientManager, ServiceManager serviceManager)
        {
            this.clientManager = clientManager;
            this.serviceManager = serviceManager;
            orders = new List<Order>();
            GenerateOrders();
        }

        public void AddOrder(Order order)
        {
            orders.Add(order);
        }

        public void RemoveOrder(Order order)
        {
            orders.Remove(order);
        }

        public List<Order> GetOrders()
        {
            return orders;
        }

        public void GenerateOrders()
        {
            Random random = new Random();
            List<Client> clients = clientManager.GetClients();
            List<Service> services = serviceManager.GetServices();
            for (int i = 0; i < 10; i++)
            {
                client = clients[random.Next(clients.Count)];
                service = services[random.Next(services.Count)];
                Order order = new Order(client, service);
                orders.Add(order);
            }
        }

    }
}
