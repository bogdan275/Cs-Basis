﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class Helper
    {
        static string[] statuses = new string[] 
        {
            "Planned",
            "In Progress",
            "Completed",
            "Cancelled" 
        };

        public static List<string>  Statuses
        {
            get
            {
                return statuses.ToList();
            }
        }
    }
}
