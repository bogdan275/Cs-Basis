﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class LaundryManager
    {
        public List<Laundry> laundries;

        public List<Equipment> equipments;
        public List<Material> materials;
        public List<Service> services;
        public List<Client> clients;

        private EquipmentManager equipmentManager;
        private MaterialManager materialManager;
        private ServiceManager serviceManager;
        private ClientManager clientManager;

        public List<Laundry> Laundries
        {
            get { return laundries; }
            set { laundries = value; }
        }


        public LaundryManager(EquipmentManager equipmentManager, MaterialManager materialManager, ServiceManager serviceManager, ClientManager clientManager)
        {
            this.equipmentManager = equipmentManager;
            this.materialManager = materialManager;
            this.serviceManager = serviceManager;
            this.clientManager = clientManager;

            laundries = new List<Laundry>();

            this.equipmentManager.GetEquipments();
            this.materialManager.GetMaterials();
            this.serviceManager.GetServices();

            GenerateLaundries();
        }

        public void AddLaundry(Laundry laundry)
        {
            laundries.Add(laundry);
        }

        public void RemoveLaundry(Laundry laundry)
        {
            laundries.Remove(laundry);
        }

        public List<Laundry> GetLaundries()
        {
            return laundries;
        }

        private void GenerateLaundries()
        {
            equipments =  equipmentManager.GetEquipments();
            materials = materialManager.GetMaterials();
            services = serviceManager.GetServices();
            clients = clientManager.GetClients();
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                string name = "Laundry" + (i + 1);
                Equipment equipment = equipments[random.Next(equipments.Count)];
                Material material = materials[random.Next(materials.Count)];
                Service service = services[random.Next(services.Count)];
                Client client = clients[random.Next(clients.Count)];
                Laundry laundry = new Laundry(name, equipment, material, service, client);
                laundries.Add(laundry);
            }


        }

    }
}
