﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class ClientManager
    {

        private List<Client> clients;
        private List<Service> services;

        public List<Client> Clients { get; set; }


        public ClientManager(List<Service> services)
        {
            this.services = services;
            clients = new List<Client>();
            GenerateClients();
        }

        public ClientManager()
        {
        }

        private void GenerateClients()
        {
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                string name = "Client" + (i + 1);
                Service service = services[random.Next(services.Count)];
                Client client = new Client(name, service);
                clients.Add(client);
            }
        }

        public void AddClient(Client client)
        {
            clients.Add(client);
        }

        public void RemoveClient(Client client)
        {
            clients.Remove(client);
        }

        public List<Client> GetClients()
        {
            return clients;
        }

        public string GenerateReport(Client client)
        {
            return $"{client.Name} has used the following services:\n" +
                   $"{client.Service.Name} - ${client.Service.Price}\n" +
                   $"Total money spent: ${client.TotalMoneySpent}\n";
        }
    }
}
