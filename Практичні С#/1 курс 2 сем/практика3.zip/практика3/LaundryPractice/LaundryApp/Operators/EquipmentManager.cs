﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaundryApp.BaseClasses;

namespace LaundryApp.Operators
{
    public class EquipmentManager
    {
        public List<Equipment> equipments;

        public EquipmentManager() 
        {
            equipments = new List<Equipment>();
            GenerateEquipments();
        }

        public void AddEquipment(Equipment equipment)
        {
            equipments.Add(equipment);
        }

        public void RemoveEquipment(Equipment equipment)
        {
            equipments.Remove(equipment);
        }

        public List<Equipment> GetEquipments()
        {
            return equipments;
        }

        private void GenerateEquipments()
        {
            equipments.Add(new Equipment("Washing Machine", 10));
            equipments.Add(new Equipment("Dryer", 10));
            equipments.Add(new Equipment("Iron", 10));
            equipments.Add(new Equipment("Folding Table", 10));
            equipments.Add(new Equipment("Drying Rack", 10));
            equipments.Add(new Equipment("Laundry Basket", 10));
            equipments.Add(new Equipment("Detergent Dispenser", 10));
        }
    }
}
