﻿namespace LaundryApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBoxEquipment = new System.Windows.Forms.ListBox();
            this.addStuffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addMaterialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.managmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createMateriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createEquipmentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createClientToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listBoxMaterial = new System.Windows.Forms.ListBox();
            this.listBoxClient = new System.Windows.Forms.ListBox();
            this.listBoxService = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.listBoxOrders = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.financialReportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.financialReportsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBoxEquipment
            // 
            this.listBoxEquipment.Enabled = false;
            this.listBoxEquipment.ItemHeight = 16;
            this.listBoxEquipment.Location = new System.Drawing.Point(30, 360);
            this.listBoxEquipment.Name = "listBoxEquipment";
            this.listBoxEquipment.Size = new System.Drawing.Size(300, 260);
            this.listBoxEquipment.TabIndex = 0;
            // 
            // addStuffToolStripMenuItem
            // 
            this.addStuffToolStripMenuItem.Name = "addStuffToolStripMenuItem";
            this.addStuffToolStripMenuItem.Size = new System.Drawing.Size(14, 24);
            // 
            // addEquipmentToolStripMenuItem
            // 
            this.addEquipmentToolStripMenuItem.Name = "addEquipmentToolStripMenuItem";
            this.addEquipmentToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.addEquipmentToolStripMenuItem.Text = "add equipment";
            // 
            // addMaterialToolStripMenuItem
            // 
            this.addMaterialToolStripMenuItem.Name = "addMaterialToolStripMenuItem";
            this.addMaterialToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.addMaterialToolStripMenuItem.Text = "add material";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addStuffToolStripMenuItem,
            this.managmentToolStripMenuItem,
            this.financialReportsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1196, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // managmentToolStripMenuItem
            // 
            this.managmentToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createToolStripMenuItem});
            this.managmentToolStripMenuItem.Name = "managmentToolStripMenuItem";
            this.managmentToolStripMenuItem.Size = new System.Drawing.Size(103, 26);
            this.managmentToolStripMenuItem.Text = "Managment";
            // 
            // createToolStripMenuItem
            // 
            this.createToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.createMateriaToolStripMenuItem,
            this.createEquipmentToolStripMenuItem,
            this.createClientToolStripMenuItem,
            this.createServiceToolStripMenuItem});
            this.createToolStripMenuItem.Name = "createToolStripMenuItem";
            this.createToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.createToolStripMenuItem.Text = "Operations";
            // 
            // createMateriaToolStripMenuItem
            // 
            this.createMateriaToolStripMenuItem.Name = "createMateriaToolStripMenuItem";
            this.createMateriaToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.createMateriaToolStripMenuItem.Text = "Materials";
            this.createMateriaToolStripMenuItem.Click += new System.EventHandler(this.createMateriaToolStripMenuItem_Click);
            // 
            // createEquipmentToolStripMenuItem
            // 
            this.createEquipmentToolStripMenuItem.Name = "createEquipmentToolStripMenuItem";
            this.createEquipmentToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.createEquipmentToolStripMenuItem.Text = "Equipments";
            this.createEquipmentToolStripMenuItem.Click += new System.EventHandler(this.createEquipmentToolStripMenuItem_Click);
            // 
            // createClientToolStripMenuItem
            // 
            this.createClientToolStripMenuItem.Name = "createClientToolStripMenuItem";
            this.createClientToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.createClientToolStripMenuItem.Text = "Clients";
            this.createClientToolStripMenuItem.Click += new System.EventHandler(this.createClientToolStripMenuItem_Click);
            // 
            // createServiceToolStripMenuItem
            // 
            this.createServiceToolStripMenuItem.Name = "createServiceToolStripMenuItem";
            this.createServiceToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.createServiceToolStripMenuItem.Text = "Services";
            this.createServiceToolStripMenuItem.Click += new System.EventHandler(this.createServiceToolStripMenuItem_Click);
            // 
            // listBoxMaterial
            // 
            this.listBoxMaterial.Enabled = false;
            this.listBoxMaterial.ItemHeight = 16;
            this.listBoxMaterial.Location = new System.Drawing.Point(30, 63);
            this.listBoxMaterial.Name = "listBoxMaterial";
            this.listBoxMaterial.Size = new System.Drawing.Size(300, 260);
            this.listBoxMaterial.TabIndex = 5;
            // 
            // listBoxClient
            // 
            this.listBoxClient.Enabled = false;
            this.listBoxClient.ItemHeight = 16;
            this.listBoxClient.Location = new System.Drawing.Point(348, 63);
            this.listBoxClient.Name = "listBoxClient";
            this.listBoxClient.Size = new System.Drawing.Size(821, 260);
            this.listBoxClient.TabIndex = 4;
            // 
            // listBoxService
            // 
            this.listBoxService.Enabled = false;
            this.listBoxService.ItemHeight = 16;
            this.listBoxService.Location = new System.Drawing.Point(348, 360);
            this.listBoxService.Name = "listBoxService";
            this.listBoxService.Size = new System.Drawing.Size(300, 260);
            this.listBoxService.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 16);
            this.label1.TabIndex = 9;
            this.label1.Text = "Materials";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(347, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "clients";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 341);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 16);
            this.label3.TabIndex = 11;
            this.label3.Text = "Equipments";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(347, 341);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 16);
            this.label4.TabIndex = 12;
            this.label4.Text = "Services";
            // 
            // listBoxOrders
            // 
            this.listBoxOrders.Enabled = false;
            this.listBoxOrders.ItemHeight = 16;
            this.listBoxOrders.Location = new System.Drawing.Point(664, 360);
            this.listBoxOrders.Name = "listBoxOrders";
            this.listBoxOrders.Size = new System.Drawing.Size(505, 260);
            this.listBoxOrders.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(661, 341);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 16);
            this.label5.TabIndex = 14;
            this.label5.Text = "Orders";
            // 
            // financialReportsToolStripMenuItem
            // 
            this.financialReportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.financialReportsToolStripMenuItem1});
            this.financialReportsToolStripMenuItem.Name = "financialReportsToolStripMenuItem";
            this.financialReportsToolStripMenuItem.Size = new System.Drawing.Size(78, 24);
            this.financialReportsToolStripMenuItem.Text = " Reports";
            // 
            // financialReportsToolStripMenuItem1
            // 
            this.financialReportsToolStripMenuItem1.Name = "financialReportsToolStripMenuItem1";
            this.financialReportsToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.financialReportsToolStripMenuItem1.Text = "Ffinancial reports";
            this.financialReportsToolStripMenuItem1.Click += new System.EventHandler(this.financialReportsToolStripMenuItem1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 657);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.listBoxOrders);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxService);
            this.Controls.Add(this.listBoxClient);
            this.Controls.Add(this.listBoxMaterial);
            this.Controls.Add(this.listBoxEquipment);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ListBox listBoxEquipment;
        private System.Windows.Forms.ToolStripMenuItem addStuffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addMaterialToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ListBox listBoxMaterial;
        private System.Windows.Forms.ToolStripMenuItem managmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createMateriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createEquipmentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createClientToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createServiceToolStripMenuItem;
        private System.Windows.Forms.ListBox listBoxClient;
        private System.Windows.Forms.ListBox listBoxService;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBoxOrders;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ToolStripMenuItem financialReportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem financialReportsToolStripMenuItem1;
    }
}

